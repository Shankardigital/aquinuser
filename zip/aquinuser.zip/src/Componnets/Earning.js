import React, { useEffect, useState } from 'react'
import Sidebar from "./Sidebar";
import Sidebarres from "./Sidebarres";
import {
  Row,
  Col,
  Card,
  CardBody,
  FormGroup,
  Button,
  CardTitle,
  Label,
  Input,
  ModalHeader, ModalBody, ModalFooter,
} from "reactstrap"
import Table from 'react-bootstrap/Table';
import Box from '@mui/material/Box';
import CssBaseline from "@mui/material/CssBaseline";
import { NavLink, Link } from "react-router-dom";
import mark from "../assets/images/mark1.jpg";
import avatar from "../assets/images/users/user-1.jpg"
import MonetizationOnIcon from '@mui/icons-material/MonetizationOn';
import Pagination from '@mui/material/Pagination';
import Stack from '@mui/material/Stack';

// import { AvForm, AvField } from "availity-reactstrap-validation"
import qrcode from "../assets/images/qrcode.png";
import Modal from 'react-bootstrap/Modal';

function Earning() {
  const [modal, setModal] = useState(false);

  const toggle = () => setModal(!modal);
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  return (
    <div>
      {/* <Sidebar/> */}

      <Box sx={{ display: "flex" }} className="cardmrg">
      <div className='backgrounimgstyle'>
          <Sidebar />
        </div>
        <div className='drawecontent'>
          <Sidebarres />
        </div>
        {/* <CssBaseline /> */}
        <Row className='continer cotainerstyle mb-5' style={{ width: "100%" }}>
          <Col md={12}>
            <div className='mb-4'>
              <h5>Earning</h5>
              <span style={{ fontSize: " 15px" }}><Link to="/Dashboard">Aquin</Link> <i class="fa fa-angle-double-right" aria-hidden="true"></i> Earning</span>
            </div>
            <Card>
             <div  style={{padding:"30px"}}>
              {/* <div>
                <p>Show entries</p>
                  <select >
                  <option>10</option>
                  <option>20</option>
                  <option>30</option>
                  </select>
              </div> */}
              <div style={{float:"right"}}>
                <input type="search" className='form-control mb-3' placeholder='Search...' style={{width:"200px"}}/>
              </div>
              <div className='table-responsive'>
             <Table striped bordered hover size="lg">
                <thead>
                  <tr>
                    <th>SNo</th>
                    <th>User Name</th>
                    <th>User Id</th>
                    <th>Coins</th>
                    <th>Date</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>1</td>
                    <td>Company 10034</td>
                    <td>198740</td>
                    <td>10</td>
                    <td>23/07/2022</td>
                  </tr>

                  <tr>
                    <td>2</td>
                    <td>Company 14034</td>
                    <td>198740</td>
                    <td>50</td>
                    <td>23/07/2022</td>
                  </tr>
                  <tr>
                    <td>3</td>
                    <td>Company 10034</td>
                    <td>198740</td>
                    <td>30</td>
                    <td>23/07/2022</td>
                  </tr>

                  <tr>
                    <td>4</td>
                    <td>Company 10034</td>
                    <td>198740</td>
                    <td>20</td>
                    <td>23/07/2022</td>
                  </tr>
                  <tr>
                    <td>5</td>
                    <td>Company 10034</td>
                    <td>198740</td>
                    <td>10</td>
                    <td>23/07/2022</td>
                  </tr>
                </tbody>
              </Table>
             </div>
              <div style={{float:"right"}} className="mt-2">
              <Pagination count={3} variant="outlined" color="primary" />
              </div>
             </div>
            </Card>

          </Col>
        </Row>

      </Box>
      {/* <Modal
          isOpen={modal}
          style={{ width: '30%', marginTop: "100px" }}
          toggle={toggle}
        >
          <ModalHeader toggle={toggle}>
              <span>QRCODE</span>
          </ModalHeader>
          <ModalBody>
            <img src={qrcode} style={{ width: "100%" }} />
          </ModalBody>
        </Modal> */}

      <Modal show={show}
        size="sm"
        style={{ marginTop: "100px" }}
        onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading </Modal.Title><span onClick={handleClose} style={{ float: "right", fontSize: "20px" }}><i class="fa fa-times-circle" aria-hidden="true"></i></span>
        </Modal.Header>
        <Modal.Body>
          <img src={qrcode} style={{ width: "100%" }} />
        </Modal.Body>

      </Modal>


    </div >
  )
}

export default Earning
