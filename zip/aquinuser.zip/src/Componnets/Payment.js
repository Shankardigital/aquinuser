import React, { useEffect, useState } from "react";
import Sidebar from "./Sidebar";
import Sidebarres from "./Sidebarres";
import {
  Row,
  Col,
  Card,
  CardBody,
  FormGroup,
  Button,
  CardTitle,
  Label,
  Input,
  Table,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from "reactstrap";
import Box from "@mui/material/Box";
import CssBaseline from "@mui/material/CssBaseline";
import { NavLink, Link } from "react-router-dom";
import mark from "../assets/images/mark1.jpg";
import avatar from "../assets/images/users/user-1.jpg";
import MonetizationOnIcon from "@mui/icons-material/MonetizationOn";

// import { AvForm, AvField } from "availity-reactstrap-validation"
import qrcode from "../assets/images/qrcode.png";
import Modal from "react-bootstrap/Modal";

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";

function Payment() {
  const [modal, setModal] = useState(false);

  const toggle = () => setModal(!modal);
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [form, setform] = useState({});

  const [Files, setFiles] = useState("");

  const changeHandler = (e) => {
    setFiles(e.target.files);
  };

  const handleChange = (e) => {
    let myUser = { ...form };
    myUser[e.target.name] = e.target.value;
    setform(myUser);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    add();
  };

  const add = () => {
    const dataArray = new FormData();
    dataArray.append("upiId", form.upiId);
    dataArray.append("refNumber", form.refNumber);
    dataArray.append("message", form.message);
    var token = sessionStorage.getItem("token");
    axios
      .post(
        "http://103.186.185.77:5013/api/v1/web/userpay/addpayinfo",
        dataArray,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      )
      .then(
        (res) => {
          if (res.status === 200) {
            toast(res.data.message);
            clearForm();
          }
        },
        (error) => {
          if (error.response && error.response.status === 400) {
            toast(error.response.data.message);
          }
        }
      );
  };

  const clearForm = () => {
    setform({
      upiId: "",
      refNumber: "",
      message: "",
    });
  };

  return (
    <div>
      {/* <Sidebar/> */}

      <Box sx={{ display: "flex" }} className="cardmrg">
        <div className="backgrounimgstyle">
          <Sidebar />
        </div>
        <div className="drawecontent">
          <Sidebarres />
        </div>
        {/* <CssBaseline /> */}
        <Row className="continer cotainerstyle2 mb-5" style={{ width: "100%" }}>
          <Col md={12}>
            <div className="mb-4">
              <h5>Payment</h5>
              <span style={{ fontSize: " 15px" }}>
                <Link to="/Dashboard">Aquin</Link>{" "}
                <i class="fa fa-angle-double-right" aria-hidden="true"></i>{" "}
                Payment
              </span>
            </div>
            <Card>
              {/* <CardTitle className="h4" style={{ padding: "20px" }}>Payment Details </CardTitle> */}
              <CardBody className="cardstyles2">
                <div className="mt-5">
                  <div className="cardstyles">
                    <form
                      method="post"
                      onSubmit={(e) => {
                        handleSubmit(e);
                      }}
                    >
                      <h5 style={{ cursor: "pointer" }} onClick={handleShow}>
                        Do the PAYMENT with QRCODE{" "}
                        <i class="fa fa-qrcode" aria-hidden="true"></i>
                      </h5>
                      <div className="needs-validation mt-3">
                        <div className="mb-4">
                          <Label htmlFor="validationCustom01">
                            UPI Id<span className="text-danger">*</span>
                          </Label>
                          <input
                            name="upiId"
                            placeholder="UPI Id"
                            type="text"
                            errorMessage="Please provide a valid UPI Id"
                            className="form-control"
                            required
                            onChange={(e) => {
                              handleChange(e);
                            }}
                            value={form.upiId}
                            id="validationCustom01"
                          />
                        </div>

                        <div className="mb-4">
                          <Label htmlFor="validationCustom02">
                            UTR/REFERENCE NO/UPI REF NO
                            <span className="text-danger">*</span>
                          </Label>
                          <input
                            placeholder="UTR/REFERENCE NO/UPI REF NO"
                            type="text"
                            errorMessage="Please provide a valid UTR/REFERENCE NO/UPI REF NO"
                            className="form-control"
                            name="refNumber"
                            required
                            onChange={(e) => {
                              handleChange(e);
                            }}
                            value={form.refNumber}
                            id="validationCustom02"
                          />
                        </div>
                        <div className="mb-4">
                          <Label htmlFor="validationCustom02">
                            Message<span className="text-danger">*</span>
                          </Label>
                          <textarea
                            className="form-control"
                            placeholder="Enter message"
                            name="message"
                            required
                            onChange={(e) => {
                              handleChange(e);
                            }}
                            value={form.message}
                          />
                        </div>

                        <div style={{ float: "right" }}>
                          <Button
                            className="success"
                            style={{ width: "150px" }}
                          >
                            Submit
                          </Button>
                        </div>
                      </div>
                    </form>
                    <ToastContainer />
                  </div>
                </div>
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Box>
      {/* <Modal
          isOpen={modal}
          style={{ width: '30%', marginTop: "100px" }}
          toggle={toggle}
        >
          <ModalHeader toggle={toggle}>
              <span>QRCODE</span>
          </ModalHeader>
          <ModalBody>
            <img src={qrcode} style={{ width: "100%" }} />
          </ModalBody>
        </Modal> */}

      <Modal
        show={show}
        size="sm"
        style={{ marginTop: "100px" }}
        onHide={handleClose}
      >
        <Modal.Header closeButton>
          <Modal.Title>Modal heading </Modal.Title>
          <span
            onClick={handleClose}
            style={{ float: "right", fontSize: "20px" }}
          >
            <i class="fa fa-times-circle" aria-hidden="true"></i>
          </span>
        </Modal.Header>
        <Modal.Body>
          <img src={qrcode} style={{ width: "100%" }} />
        </Modal.Body>
      </Modal>

      {/* <Modal isOpen={modal} fade={false} toggle={toggle}>
        <ModalHeader toggle={toggle}>Modal title</ModalHeader>
        <ModalBody>
          Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do
          eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad
          minim veniam, quis nostrud exercitation ullamco laboris nisi ut
          aliquip ex ea commodo consequat. Duis aute irure dolor in
          reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla
          pariatur. Excepteur sint occaecat cupidatat non proident, sunt in
          culpa qui officia deserunt mollit anim id est laborum.
        </ModalBody>
        <ModalFooter>
          <Button color="primary" onClick={toggle}>
            Do Something
          </Button>{' '}
          <Button color="secondary" onClick={toggle}>
            Cancel
          </Button>
        </ModalFooter>
      </Modal> */}
    </div>
  );
}

export default Payment;
