import React, { useEffect, useState } from 'react'
import Sidebar from "./Sidebar";
import Sidebarres from "./Sidebarres";
import {
  Row,
  Col,
  Card,
  CardBody,
  FormGroup,
  Button,
  CardTitle,
  Label,
  Input,
  ModalHeader, ModalBody, ModalFooter,
} from "reactstrap"
import Table from 'react-bootstrap/Table';
import Box from '@mui/material/Box';
import CssBaseline from "@mui/material/CssBaseline";
import { NavLink, Link } from "react-router-dom";
import mark from "../assets/images/mark1.jpg";
import avatar from "../assets/images/users/user-1.jpg"
import MonetizationOnIcon from '@mui/icons-material/MonetizationOn';
import Pagination from '@mui/material/Pagination';
import Stack from '@mui/material/Stack';
import qrcode from "../assets/images/qrcode.png";
import Modal from 'react-bootstrap/Modal';

function Withdrawal() {
  const [modal, setModal] = useState(false);

  const toggle = () => setModal(!modal);
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);

  const [showResults, setShowResults] = React.useState(false);
  const showfield = () => setShowResults(true);
  const hidefield = () => setShowResults(false);
  return (
    <div>
      {/* <Sidebar/> */}

      <Box sx={{ display: "flex" }} className="cardmrg">
      <div className='backgrounimgstyle'>
                    <Sidebar />
                </div>
                <div className='drawecontent'>
                    <Sidebarres />
                </div>
        {/* <CssBaseline /> */}
        <Row className='continer cotainerstyle mb-5' style={{ width: "100%" }}>
          <Col md={12}>
            <div className='mb-4'>
              <h5>Withdrawal Request</h5>
              <span style={{ fontSize: " 15px" }}><Link to="/Dashboard">Aquin</Link> <i class="fa fa-angle-double-right" aria-hidden="true"></i> Withdrawal</span>
            </div>

            {showResults ? (
              <Card>
                <CardBody>
                  <div>
                    <div className="needs-validation">
                      <Row>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom01">Coins</Label>
                            <input
                              name="Coins"
                              placeholder="Enter Coins"
                              type="number"
                              errorMessage="Enter Coins"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom01"
                            />
                          </div>
                        </Col>
                        {/* <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom01">Date</Label>
                            <input
                              name="Date"
                              placeholder="Enter Date"
                              type="date"
                              errorMessage="Enter Date"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom07"
                            />
                          </div>
                        </Col> */}
                        {/* <Col md="2">
                        <div className="mb-4">
                          <Label htmlFor="validationCustom02">Level No</Label>
                          <select className="form-control">
                            <option>All</option>
                            <option>1</option>
                            <option>2</option>
                            <option>3</option>
                            <option>4</option>
                          </select>
                        </div>
                      </Col> */}
                        <Col md="4">
                          <div className="mb-4 mt-4">
                            <Button className="btn btn-success listbtns" style={{ width: "110px" }}>Submit</Button>
                            <Button className="btn-danger listbtns" style={{ width: "110px" }} onClick={hidefield}>Cancel</Button>
                          </div>
                        </Col>
                      </Row>
                    </div>
                  </div>
                </CardBody>
              </Card>
            ) : (
              ""
            )}

            <Card>
              <div style={{ float: "right" }} className="" >

              </div>
              <div style={{ padding: "30px" }}>
                {/* <div>
                <p>Show entries</p>
                  <select >
                  <option>10</option>
                  <option>20</option>
                  <option>30</option>
                  </select>
              </div> */}
                <div style={{ float: "right" }} >
                  <div class="form-inline my-2 my-lg-0">
                  <button className="btn btn-outline-primary my-2 my-sm-0 adgustwidth"
                    onClick={() => {
                      setShowResults(!showResults);
                    }}><i class="fa fa-plus-circle" aria-hidden="true"></i> Withdrawl</button>
                  <input type="search" className='form-control mb-3 mt-3 ml-3 adgustwidth' placeholder='Search...' style={{ width: "200px" }} />
                   
                  </div>
                  
                </div>
                <div className='table-responsive'>
                  <Table striped bordered hover size="lg">
                    <thead>
                      <tr>
                        <th>SNo</th>
                        <th>Coins</th>
                        <th>UAmount</th>
                        <th>Request Date</th>
                        <th>Status</th>
                        <th>Approved Date</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr>
                        <td>1</td>
                        <td>50</td>
                        <td>500</td>
                        <td>09/10/2021</td>
                        <td>Completed</td>
                        <td>15/10/2021</td>
                      </tr>

                      <tr>
                        <td>2</td>
                        <td>150</td>
                        <td>1500</td>
                        <td>09/10/2021</td>
                        <td>Pending</td>
                        <td></td>
                      </tr>
                      <tr>
                        <td>3</td>
                        <td>100</td>
                        <td>1000</td>
                        <td>09/10/2021</td>
                        <td>Pending</td>
                        <td></td>
                      </tr>

                      <tr>
                        <td>4</td>
                        <td>50</td>
                        <td>500</td>
                        <td>09/10/2021</td>
                        <td>Completed</td>
                        <td>15/10/2021</td>
                      </tr>
                      <tr>
                        <td>5</td>
                        <td>50</td>
                        <td>500</td>
                        <td>09/10/2021</td>
                        <td>Completed</td>
                        <td>15/10/2021</td>
                      </tr>
                    </tbody>
                  </Table>
                </div>
                <div style={{ float: "right" }} className="mt-2">
                  <Pagination count={3} variant="outlined" color="primary" />
                </div>
              </div>
            </Card>

          </Col>
        </Row>

      </Box>
      {/* <Modal
          isOpen={modal}
          style={{ width: '30%', marginTop: "100px" }}
          toggle={toggle}
        >
          <ModalHeader toggle={toggle}>
              <span>QRCODE</span>
          </ModalHeader>
          <ModalBody>
            <img src={qrcode} style={{ width: "100%" }} />
          </ModalBody>
        </Modal> */}

      <Modal show={show}
        size="sm"
        style={{ marginTop: "100px" }}
        onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading </Modal.Title><span onClick={handleClose} style={{ float: "right", fontSize: "20px" }}><i class="fa fa-times-circle" aria-hidden="true"></i></span>
        </Modal.Header>
        <Modal.Body>
          <img src={qrcode} style={{ width: "100%" }} />
        </Modal.Body>

      </Modal>


    </div >
  )
}

export default Withdrawal
