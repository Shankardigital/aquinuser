import React, { useEffect, useState } from 'react'
import Sidebar from "./Sidebar";
import Sidebarres from "./Sidebarres";
import {
  Row,
  Col,
  Card,
  CardBody,
  FormGroup,
  Button,
  CardTitle,
  Label,
  Input,
  Table,
   ModalHeader, ModalBody, ModalFooter,
} from "reactstrap"
import Box from '@mui/material/Box';
import CssBaseline from "@mui/material/CssBaseline";
import { NavLink, Link } from "react-router-dom";
import mark from "../assets/images/mark1.jpg";
import avatar from "../assets/images/users/user-1.jpg"
import MonetizationOnIcon from '@mui/icons-material/MonetizationOn';

// import { AvForm, AvField } from "availity-reactstrap-validation"
import qrcode from "../assets/images/qrcode.png";
import Modal from 'react-bootstrap/Modal';

function Letter() {
  const [modal, setModal] = useState(false);

  const toggle = () => setModal(!modal);
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  return (
    <div>
      {/* <Sidebar/> */}

      <Box sx={{ display: "flex" }} className="cardmrg">
      <div className='backgrounimgstyle'>
          <Sidebar />
        </div>
        <div className='drawecontent'>
          <Sidebarres />
        </div>
        {/* <CssBaseline /> */}
        <Row className='continer modulepad cotainerstyle2 mb-5' style={{ width: "100%" }}>
          <Col md={12}>
            <div className='mb-4'>
              <h5>Welcome letter</h5>
              <span style={{ fontSize: " 15px" }}><Link to="/Dashboard">Aquin</Link> <i class="fa fa-angle-double-right" aria-hidden="true"></i> Welcome letter</span>
            </div>
            <Card>
                <button className='form-control'>Coming soon...</button>
            </Card>

          </Col>
        </Row>

      </Box>
      {/* <Modal
          isOpen={modal}
          style={{ width: '30%', marginTop: "100px" }}
          toggle={toggle}
        >
          <ModalHeader toggle={toggle}>
              <span>QRCODE</span>
          </ModalHeader>
          <ModalBody>
            <img src={qrcode} style={{ width: "100%" }} />
          </ModalBody>
        </Modal> */}

      <Modal show={show}
       size="sm"
       style={{marginTop: "100px" }}
       onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading </Modal.Title><span onClick={handleClose} style={{float:"right" ,fontSize:"20px"}}><i class="fa fa-times-circle" aria-hidden="true"></i></span>
        </Modal.Header>
        <Modal.Body>
        <img src={qrcode} style={{ width: "100%" }} />
        </Modal.Body>
  
      </Modal>

   
    </div >
  )
}

export default Letter
