import React from 'react'
import { Row, Col, CardBody, Card, Alert, Container, Label } from "reactstrap"
import { withRouter, Link } from "react-router-dom"
import logo from "../assets/images/logo.png";

function Forgot() {
    return (
        <div>
            <div className="account-pages my-5 pt-sm-5">
                <Container>
                    <Row className="justify-content-center">
                        <Col md={8} lg={6} xl={5}>
                            <Card className="overflow-hidden">
                                <CardBody className="pt-0">
                                    <h3 className="text-center mt-4">
                                        <Link to="/" className="d-block auth-logo">
                                        <img src={logo} style={{width:"200px"}} className="auth-logo-dark" />

                                            {/* <img src={logoDark} alt="" height="30" className="auth-logo-dark" />
                      <img src={logoLightPng} alt="" height="30" className="auth-logo-light" /> */}
                                        </Link>
                                    </h3>
                                    {/* <h2 className='text-center text-primary'>Aquin</h2> */}
                                    <div className="p-3">
                                        <h4 className="text-muted font-size-18 mb-3 text-center">Reset Password</h4>
                                        <div className="alert alert-info" role="alert">
                                            Enter your Email and instructions will be sent to you!
                                        </div>
                                        {/* {props.forgetError && props.forgetError ? (
                      <Alert color="danger" style={{ marginTop: "13px" }}>
                        {props.forgetError}
                      </Alert>
                    ) : null}
                    {props.forgetSuccessMsg ? (
                      <Alert color="success" style={{ marginTop: "13px" }}>
                        {props.forgetSuccessMsg}
                      </Alert>
                    ) : null} */}

                                        <div
                                            className="form-horizontal mt-4"
                                        //   onValidSubmit={(e, v) => handleValidSubmit(e, v)}
                                        >
                                            <div className="mb-3">
                                                <Label>Email</Label>
                                                <input
                                                    name="email"
                                                    className="form-control"
                                                    placeholder="Enter email"
                                                    type="email"
                                                    required
                                                />
                                            </div>
                                            {/* <Row className="mb-3">
                        <Col className="text-end">
                          <button
                            className="btn btn-primary w-md waves-effect waves-light"
                            type="submit"
                          >
                            Reset
                          </button>
                        </Col>
                      </Row> */}
                                            <div style={{ float: "right" }}>
                                                <button style={{ width: "100px" }} className="btn btn-info w-md waves-effect waves-light" type="submit">Reset</button>

                                            </div>
                                        </div>
                                    </div>
                                </CardBody>
                            </Card>
                            <div className="mt-5 text-center">
                                <p>
                                    Remember It ?{" "}
                                    <Link to="/" className="text-primary">
                                        Sign In Here
                                    </Link>{" "}
                                </p>
                                <p>
                                    © {new Date().getFullYear()} Aquin
                                    <span className="d-none d-sm-inline-block"> - Designed <i class="fa fa-heart text-danger" aria-hidden="true"></i> by DigitalRaiz Creative Solutions.</span>
                                </p>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </div>
        </div>
    )
}

export default Forgot