import React from 'react'
import Sidebar from "./Sidebar";
import Sidebarres from "./Sidebarres";

import {
    Row,
    Col,
    Card,
    CardBody,
    FormGroup,
    Button,
    CardTitle,
    Label,
    Input,
} from "reactstrap"
import Box from '@mui/material/Box';
import CssBaseline from "@mui/material/CssBaseline";
import { NavLink, Link } from "react-router-dom";
import mark from "../assets/images/mark1.jpg";
import avatar from "../assets/images/users/user-1.jpg"
import MonetizationOnIcon from '@mui/icons-material/MonetizationOn';

import ReactApexChart from 'react-apexcharts';

import "../common.css"

import coin from '../assets/images/coin.png'



function Dashboard() {


    const state = {
        options: {
            colors: ['#28bbe3', '#F0F1F4'],
            chart: {
                stacked: true,
                toolbar: {
                    show: false,
                },
            },
            dataLabels: {
                enabled: false,
            },
            plotOptions: {
                bar: {
                    columnWidth: '70%',
                },
            },
            grid: {
                borderColor: '#f8f8fa',
                row: {
                    colors: ['transparent', 'transparent'], // takes an array which will be repeated on columns
                    opacity: 0.5
                },
            },

            xaxis: {
                categories: [2005, 2006, 2007, 2008, 2009, 2010, 2011, 2012, 2013, 2014, 2015, 2016],
                labels: {
                    formatter: function (val) {
                        return val
                    },
                },
                axisBorder: {
                    show: false
                },
                axisTicks: {
                    show: false
                }
            },
            yaxis: {
                title: {
                    text: undefined
                },
            },
            tooltip: {
                y: {
                    formatter: function (val) {
                        return val
                    }
                }
            },
            fill: {
                opacity: 1
            },

            legend: {
                show: false,
                position: 'top',
                horizontalAlign: 'left',
                offsetX: 40
            }
        },
        series: [{
            name: 'Series A',
            data: [45, 75, 100, 75, 100, 75, 50, 75, 50, 75, 100, 80]
        }, {
            name: 'Series B',
            data: [180, 65, 90, 65, 90, 65, 40, 65, 40, 65, 90, 65]
        }],
    }



   const states = {
          
        series: [{
            name: "Desktops",
            data: [10, 41, 35, 51, 49, 62, 69, 91, 148]
        }],
        options: {
          chart: {
            height: 350,
            type: 'line',
            zoom: {
              enabled: false
            }
          },
          dataLabels: {
            enabled: false
          },
          stroke: {
            curve: 'straight'
          },
          title: {
            text: 'Product Trends by Month',
            align: 'left'
          },
          grid: {
            row: {
              colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
              opacity: 0.5
            },
          },
          xaxis: {
            categories: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep'],
          }
        },
      
      
      };

    return (
        <div>
            {/* <Sidebar/> */}

            <Box sx={{ display: "flex" }} className="cardmrg">
                <div className='backgrounimgstyle'>
                    <Sidebar />
                </div>
                <div className='drawecontent'>
                    <Sidebarres />
                </div>
                {/* <CssBaseline /> */}

                <Row className='continer cotainerstyle mb-5' style={{ width: "100%" }}>
                    <Col md={12}>
                        <h5>Dashboard</h5>
                        {/* <div className='mb-4'>
                            <h5>Dashboard</h5>
                            <span style={{ fontSize: " 15px" }}><Link to="/Dashboard">Aquin</Link> <i class="fa fa-angle-double-right" aria-hidden="true"></i> Dashboard</span>
                        </div> */}
                        <Row>
                            <Col md={3}>
                                <Card className="mini-stat" style={{ background: '#c7b2eb', borderRadius: '10px' }}>
                                    <CardBody className="card-body mini-stat-img" >
                                        <div className="mini-stat-icon" style={{ float: "right" }} >
                                            <i style={{ color: "#fff", background: 'white' }} class="fa fa-cube" aria-hidden="true" ></i>
                                        </div>
                                        <div>
                                            <h6 className="mb-3 font-size-16" >My Directs</h6>
                                            <h6 className="mb-4 text-dark">2</h6></div>
                                    </CardBody>
                                </Card>
                            </Col>
                            <Col md={3} >
                                <Card className="mini-stat" style={{ background: '#dff0a1', borderRadius: '10px' }}>
                                    <CardBody className="card-body mini-stat-img">
                                        <div className="mini-stat-icon" style={{ float: "right" }}>
                                            <i style={{ color: "#fff", background: 'white' }} class="fa fa-users" aria-hidden="true"></i>
                                        </div>
                                        <div className="text-dark">
                                            <h6 className="mb-3 font-size-16 text-dark">Total Team</h6>
                                            <h6 className="mb-4 text-dark">43</h6></div>
                                    </CardBody>
                                </Card>
                            </Col>
                            <Col md={3} >
                                <Card className="mini-stat" style={{ background: '#b7e5f7', borderRadius: '10px' }}>
                                    <CardBody className="card-body mini-stat-img">
                                        <div className="mini-stat-icon" style={{ float: "right" }}>

                                            <i style={{ background: 'white' }}><img src={coin} height="60" alt="" /></i>
                                        </div>
                                        <div className="text-dark">
                                            <h6 className=" mb-3 font-size-16 text-dark" style={{ color: "black", fontWeight: 'bold' }}>Total Coins</h6>
                                            <h6 className="mb-4 text-dark">₹200</h6></div>
                                    </CardBody>
                                </Card>
                            </Col>
                            <Col md={3}>
                                <Card className="mini-stat" style={{ background: '#94d1a0', borderRadius: '10px' }}>
                                    <CardBody className="card-body mini-stat-img" >
                                        <div className="mini-stat-icon" style={{ float: "right" }}>
                                            <i style={{ color: "#fff", background: 'white' }} class="fa fa-bell" aria-hidden="true"></i>
                                        </div>
                                        <div className="text-dark">
                                            <h6 className=" mb-3 font-size-16 text-dark" style={{ color: "black", fontWeight: 'bold' }}>Notification</h6>
                                            <h6 className="mb-4 text-dark">30</h6></div>
                                    </CardBody>
                                </Card>


                            </Col>
                        </Row>



                        <Row>
                            <Col md="6">
                                <Card>
                                    <CardBody>
                                        <CardTitle className="h4 mb-4">Daily Coins Earnings</CardTitle>

                                        <Row className="text-center mt-4">
                                            <div className="col-6">
                                                <h5 className="font-size-20">₹56241</h5>
                                                <p className="text-muted">Marketplace</p>
                                            </div>
                                            <div className="col-6">
                                                <h5 className="font-size-20">₹23651</h5>
                                                <p className="text-muted">Total Income</p>
                                            </div>
                                        </Row>
                                        <div dir="ltr">
                                            <React.Fragment>
                                            <ReactApexChart options={states.options} series={states.series} type="line" height={290} />
                                            </React.Fragment>
                                        </div>

                                    </CardBody>
                                </Card></Col>
                            <Col md="6">
                                <Card>
                                    <CardBody>
                                        <h4 className="card-title mb-4">Monthly Earnings</h4>

                                        <Row className="text-center mt-4">
                                            <Col xs="6">
                                                <h5 className="font-size-20">₹ 2548</h5>
                                                <p className="text-muted">Marketplace</p>
                                            </Col>
                                            <Col xs="6">
                                                <h5 className="font-size-20">₹ 6985</h5>
                                                <p className="text-muted">Total Income</p>
                                            </Col>
                                        </Row>

                                        <div id="morris-bar-stacked" className="morris-charts morris-charts-height" dir="ltr">
                                            <ReactApexChart options={state.options} series={state.series} type="bar" height="290" />
                                        </div>
                                    </CardBody>
                                </Card>
                            </Col>
                        </Row>


                        <Row >
                            {/* <div className="row mb-4 mt-3 ml-2 mr-2 ">
                                <div className="col col-lg-4 backgrounimgstyle ">
                                    <div >
                                        <img src={mark} style={{ width: "115%", height: "164px" }} />
                                    </div>
                                </div>
                                <div className="col col-lg-8">
                                    <div className="bg-white ">
                                        <div style={{ padding: "17px" }}>
                                            <h5 className="text-center">Aquin Ads</h5>
                                            <p className="text-center">where advertisers bid to display brief advertisements, service offerings, product listings, or videos to web users.</p>
                                            <div className="d-flex justify-content-center">
                                                <Link to="/advertisements"><button className="btn btn-info " style={{ width: "140px", fontSize: "17px" }}><i class="fa fa-bullhorn" aria-hidden="true"></i> Ads</button></Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div> */}
                            {/* <Row className="mb-4 adsimgstyel cotainerstyle">
                                <div style={{ backgroundImage: `url(₹{mark})` }} className="backgrounimg">
                                    <div style={{ float: "right" }} className="bg-white ">
                                        <div style={{ padding: "16px" }}>
                                            <h5 className="text-center">Aquin Ads</h5>
                                            <p className="text-center">where advertisers bid to display brief advertisements, service offerings, product listings, or videos to web users.</p>
                                            <div className="d-flex justify-content-center">
                                                <Link to="advertisements"><button className="btn btn-info " style={{ width: "140px", fontSize: "17px" }}><i className="fas fa-bullhorn"></i> Ads</button></Link>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </Row> */}
                        </Row>

                        <Row className="mt-4">
                            <Col xl="4">
                                <Card className="directory-card">
                                    <div>
                                        <div className="directory-bg text-center">
                                            <div className="directory-overlays">
                                                <img className="rounded-circle avatar-lg img-thumbnail" style={{ width: "100px" }} src={avatar} alt="Generic placeholder" />
                                            </div>
                                        </div>

                                        <div className="directory-content text-center p-4">
                                            <p className="font-size-16 mt-4 ">Member Id :100935</p>
                                            <h5 className="font-size-16">Katherine J. McAvoy</h5>

                                        </div>
                                    </div>
                                    <div style={{ paddingLeft: "20px" }}>
                                        <div className="row">
                                            <div className="col" >
                                                <p><b>Registration:</b></p>
                                                <p><b>ID Status:</b></p>
                                            </div>
                                            <div className="col">
                                                <p><b>04/09/2021</b></p>
                                                <p><b>Active</b></p>
                                            </div>
                                        </div>
                                    </div>
                                </Card>
                            </Col>

                            <Col xl="4">
                                {/* <MonthlyEarnings2 /> */}
                                <Card className="directory-card">
                                    <div>
                                        <div className="directory-bg text-center">
                                            <div className="directory-overlays">
                                                <h6 className="text-white">Today coin prices</h6>
                                                {/* <img className="rounded-circle avatar-lg img-thumbnail" src={avatar} alt="Generic placeholder" /> */}
                                            </div>
                                        </div>

                                        <div className="directory-content text-center p-4">
                                            <p>This is Today our basic coin values or coin price</p>
                                            <h5 style={{ fontSize: "30px" }} className="mt-3">5   <img src={coin} height="50" alt="" /> = <i class="fa fa-inr" aria-hidden="true"></i> 50</h5>
                                            {/* <h5 className="font-size-16">http://ctmember.mlmconsultancy.co.in/?100001</h5> */}
                                            {/* <p className="font-size-16">Id No :100935</p> */}
                                        </div>
                                        {/* <div className="directory-content text-center p-2" style={{background:"#e1e1e1"}}>
                <Button className="btn-success" style={{margin:"5px"}}><i class="fab fa-whatsapp" aria-hidden="true"></i> WhatsApp</Button>
                <Button className="btn-info "><i class="fab fa-facebook" aria-hidden="true"></i>  Facebook</Button>
               
              </div> */}

                                    </div>
                                </Card>

                            </Col>

                            <Col xl="4">
                                {/* Email sent */}
                                {/* <EmailSent /> */}

                                <Card className="directory-card mb-5">
                                    <div>
                                        <div className="directory-bg text-center">
                                            <div className="directory-overlays">
                                                <h6 className="text-white">Share your Referral Link</h6>
                                                {/* <img className="rounded-circle avatar-lg img-thumbnail" src={avatar} alt="Generic placeholder" /> */}
                                            </div>
                                        </div>

                                        <div className="directory-content text-center p-4">
                                            <h6 className="font-size-16">http://ctmember.mlmconsultancy.co.in/?100001</h6>
                                            {/* <p className="font-size-16">Id No :100935</p> */}
                                        </div>
                                        <div className="directory-content text-center p-2" style={{ background: "#e1e1e1" }}>
                                            <Button className="btn-success" target="_blank" href="http://web.whatsapp.com/send?text=http://ctmember.mlmconsultancy.co.in/?100001" style={{ margin: "5px" }}><i class="fa fa-whatsapp" aria-hidden="true"></i> WhatsApp</Button>
                                            <Button className="btn-info " target="_blank" href="https://www.facebook.com/send?text=http://ctmember.mlmconsultancy.co.in/?100001"><i class="fa fa-facebook" aria-hidden="true"></i>  Facebook</Button>
                                            {/* <p className="font-size-16">Id No :100935</p> */}
                                        </div>

                                    </div>
                                </Card>

                            </Col>
                        </Row>

                    </Col>
                </Row>


                {/* <Row className="mb-4 adsimgstyel">
                    <div style={{ backgroundImage: `url(₹{mark})` }} className="backgrounimg">
                        <div style={{ float: "right" }} className="bg-white ">
                            <div style={{ padding: "16px" }}>
                                <h5 className="text-center">Aquin Ads</h5>
                                <p className="text-center">where advertisers bid to display brief advertisements, service offerings, product listings, or videos to web users.</p>
                                <div className="d-flex justify-content-center">
                                    <Link to="advertisements"><button className="btn btn-info " style={{ width: "140px", fontSize: "17px" }}><i className="fas fa-bullhorn"></i> Ads</button></Link>
                                </div>
                            </div>
                        </div>
                    </div>
                </Row> */}
            </Box>
        </div>
    )
}

export default Dashboard
