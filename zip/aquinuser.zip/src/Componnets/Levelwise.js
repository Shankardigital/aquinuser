import React, { useEffect, useState } from 'react'
import Sidebar from "./Sidebar";
import Sidebarres from "./Sidebarres";
import {
  Row,
  Col,
  Card,
  CardBody,
  FormGroup,
  Button,
  CardTitle,
  Label,
  Input,
  ModalHeader, ModalBody, ModalFooter,
} from "reactstrap"
import Table from 'react-bootstrap/Table';
import Box from '@mui/material/Box';
import CssBaseline from "@mui/material/CssBaseline";
import { NavLink, Link } from "react-router-dom";
import mark from "../assets/images/mark1.jpg";
import avatar from "../assets/images/users/user-1.jpg"
import MonetizationOnIcon from '@mui/icons-material/MonetizationOn';
import Pagination from '@mui/material/Pagination';
import Stack from '@mui/material/Stack';
import pdfMake from "pdfmake";
import pdfFonts from "pdfmake/build/vfs_fonts";
import htmlToPdfmake from "html-to-pdfmake";
import ReactHTMLTableToExcel from "react-html-table-to-excel";

// import { AvForm, input } from "availity-reactstrap-validation"
import qrcode from "../assets/images/qrcode.png";
import Modal from 'react-bootstrap/Modal';

function Levelwise() {
  const [modal, setModal] = useState(false);

  const toggle = () => setModal(!modal);
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [showResults, setShowResults] = React.useState(false);
  const showfield = () => setShowResults(true);
  const hidefield = () => setShowResults(false);

  const exportPDF = () => {
    const pdfTable = document.getElementById("dataList");
    var html = htmlToPdfmake(pdfTable.innerHTML);
    const documentDefinition = { content: html };
    pdfMake.vfs = pdfFonts.pdfMake.vfs;
    pdfMake.createPdf(documentDefinition).open();
  };
  return (
    <div>

      <Box sx={{ display: "flex" }} className="cardmrg">
        <div className='backgrounimgstyle'>
          <Sidebar />
        </div>
        <div className='drawecontent'>
          <Sidebarres />
        </div>
        {/* <CssBaseline /> */}
        <Row className='continer cotainerstyle mb-5' style={{ width: "100%" }}>
          <Col md={12}>
            <div className='mb-4'>
              <h5>List of Levelwise Team Member(s)</h5>
              <span style={{ fontSize: " 15px" }}><Link to="/Dashboard">Aquin</Link> <i class="fa fa-angle-double-right" aria-hidden="true"></i> Levelwise Team</span>
            </div>

            {showResults ? (
              <Card>
                <CardBody>
                  <div>
                    <div className="needs-validation">
                      <Row>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom01">From Date</Label>
                            <input
                              name="FromDate"
                              placeholder="From Date"
                              type="date"
                              errorMessage="From Date"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom01"
                            />
                          </div>
                        </Col>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom01">To Date</Label>
                            <input
                              name="To Date"
                              placeholder="To Date"
                              type="date"
                              errorMessage="To Date"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom07"
                            />
                          </div>
                        </Col>
                        <Col md="2">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom02">Level No</Label>
                            <select className="form-control">
                              <option>All</option>
                              <option>1</option>
                              <option>2</option>
                              <option>3</option>
                              <option>4</option>
                            </select>
                          </div>
                        </Col>
                        <Col md="4">
                          <div className="mb-4 mt-4">
                            <Button className="btn btn-success listbtns">Submit</Button>
                            <Button className="btn-danger listbtns" onClick={hidefield}>Cancel</Button>
                          </div>
                        </Col>
                      </Row>
                    </div>
                  </div>
                </CardBody>
              </Card>
            ) : (
              ""
            )}
            <Card>
              <div style={{ padding: "30px" }}>
                {/* <div>
                <p>Show entries</p>
                  <select >
                  <option>10</option>
                  <option>20</option>
                  <option>30</option>
                  </select>
              </div> */}
                <div style={{ float: "right" }}>
                  <div className='form-group'>
                    <button onClick={exportPDF} className="btn btn-danger listbtns"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> PDF</button>
                    {/* <button className="btn btn-success listbtns"><i class="fa fa-file-excel-o" aria-hidden="true"></i> Excel</button> */}
                    <span>
                    <ReactHTMLTableToExcel
                          className="btn btn-success"
                          table="xin_table"
                          filename="tablexls"
                          sheet="tablexls"
                          buttonText="Excel"
                        />
                      {/* <ReactHTMLTableToExcel
                        id="test-table-xls-button"
                        className="btn btn-success"
                        table="dataList"
                        filename="dataList"
                        sheet="dataList"
                        buttonText="Excel" /> */}
                    </span>
                    <button className="btn btn-primary listbtns"
                      onClick={() => {
                        setShowResults(!showResults);
                      }}><i class="fa fa-filter" aria-hidden="true"></i> Filter</button>
                  </div>
                </div>

                <div style={{ float: "right", marginTop: "7px" }}>
                  <input type="search" className='form-control mb-3 membtnstyle' placeholder='Search...' style={{ width: "250px" }} /></div>
                <div className='table-responsive'>
                  <div id="dataList">
                    <Table striped bordered hover size="sm" id="xin_table">
                      <thead>
                        <tr>
                          <th>SNo</th>
                          <th>Member Id</th>
                          <th>Member</th>
                          <th>Sponsor Code</th>
                          <th>Sponsor Name</th>
                          <th>D O J</th>
                          <th>Status</th>
                          <th>Active Details</th>
                          <th>Level</th>
                        </tr>
                      </thead>
                      <tbody>
                        <tr>
                          <td>1</td>
                          <td>139140</td>
                          <td>Company 10002</td>
                          <td>139140</td>
                          <td>Company 10002</td>
                          <td>09/10/2021</td>
                          <td>Active</td>
                          <td>14600- 09/10/2021 06:46:52 PM,</td>
                          <td>1</td>
                        </tr>

                        <tr>
                          <td>2</td>
                          <td>139140</td>
                          <td>Company 10002</td>
                          <td>139140</td>
                          <td>Company 10002</td>
                          <td>09/10/2021</td>
                          <td>Active</td>
                          <td>14600- 09/10/2021 06:46:52 PM,</td>
                          <td>1</td>
                        </tr>
                        <tr>
                          <td>3</td>
                          <td>139140</td>
                          <td>Company 10002</td>
                          <td>139140</td>
                          <td>Company 10002</td>
                          <td>09/10/2021</td>
                          <td>Active</td>
                          <td>14600- 09/10/2021 06:46:52 PM,</td>
                          <td>1</td>
                        </tr>
                        <tr>
                          <td>4</td>
                          <td>139140</td>
                          <td>Company 10002</td>
                          <td>139140</td>
                          <td>Company 10002</td>
                          <td>09/10/2021</td>
                          <td>Active</td>
                          <td>14600- 09/10/2021 06:46:52 PM,</td>
                          <td>1</td>
                        </tr>
                        <tr>
                          <td>5</td>
                          <td>139140</td>
                          <td>Company 10002</td>
                          <td>139140</td>
                          <td>Company 10002</td>
                          <td>09/10/2021</td>
                          <td>Active</td>
                          <td>14600- 09/10/2021 06:46:52 PM,</td>
                          <td>1</td>
                        </tr>

                        <tr>
                          <td>6 </td>
                          <td>139140</td>
                          <td>Company 10002</td>
                          <td>139140</td>
                          <td>Company 10002</td>
                          <td>09/10/2021</td>
                          <td>Active</td>
                          <td>14600- 09/10/2021 06:46:52 PM,</td>
                          <td>1</td>
                        </tr>
                      </tbody>
                    </Table>
                  </div>
                </div>
                <div style={{ float: "right" }} className="mt-2">
                  <Pagination count={3} variant="outlined" color="primary" />
                </div>
              </div>
            </Card>

          </Col>
        </Row>

      </Box>
      {/* <Modal
          isOpen={modal}
          style={{ width: '30%', marginTop: "100px" }}
          toggle={toggle}
        >
          <ModalHeader toggle={toggle}>
              <span>QRCODE</span>
          </ModalHeader>
          <ModalBody>
            <img src={qrcode} style={{ width: "100%" }} />
          </ModalBody>
        </Modal> */}

      <Modal show={show}
        size="sm"
        style={{ marginTop: "100px" }}
        onHide={handleClose}>
        <Modal.Header closeButton>
          <Modal.Title>Modal heading </Modal.Title><span onClick={handleClose} style={{ float: "right", fontSize: "20px" }}><i class="fa fa-times-circle" aria-hidden="true"></i></span>
        </Modal.Header>
        <Modal.Body>
          <img src={qrcode} style={{ width: "100%" }} />
        </Modal.Body>

      </Modal>


    </div >
  )
}

export default Levelwise
