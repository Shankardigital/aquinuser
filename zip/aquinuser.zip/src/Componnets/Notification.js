import React, { useEffect, useState } from 'react'
import Sidebar from "./Sidebar";
import Sidebarres from "./Sidebarres";
import {
    Row,
    Col,
    Card,
    CardBody,
    FormGroup,
    Button,
    CardTitle,
    Label,
    Input,
    ModalHeader, ModalBody, ModalFooter,
} from "reactstrap"
import Table from 'react-bootstrap/Table';
import Box from '@mui/material/Box';
import CssBaseline from "@mui/material/CssBaseline";
import { NavLink, Link } from "react-router-dom";
import mark from "../assets/images/mark1.jpg";
import avatar from "../assets/images/users/user-1.jpg"
import MonetizationOnIcon from '@mui/icons-material/MonetizationOn';
import Pagination from '@mui/material/Pagination';
import Stack from '@mui/material/Stack';

// import { AvForm, input } from "availity-reactstrap-validation"
import qrcode from "../assets/images/qrcode.png";
import Modal from 'react-bootstrap/Modal';

function Levelwise() {
    const [modal, setModal] = useState(false);

    const toggle = () => setModal(!modal);
    const [show, setShow] = useState(false);

    const handleClose = () => setShow(false);
    const handleShow = () => setShow(true);
    const [showResults, setShowResults] = React.useState(false);
    const showfield = () => setShowResults(true);
    const hidefield = () => setShowResults(false);

    return (
        <div>
            {/* <Sidebar/> */}

            <Box sx={{ display: "flex" }} className="cardmrg">
            <div className='backgrounimgstyle'>
          <Sidebar />
        </div>
        <div className='drawecontent'>
          <Sidebarres />
        </div>
                {/* <CssBaseline /> */}
                <Row className='continer cotainerstyle2 mb-5' style={{ width: "100%" }}>
                    <Col md={12}>
                        <div className='mb-4'>
                            <h5>Notifications</h5>
                            <span style={{ fontSize: " 15px" }}><Link to="/Dashboard">Aquin</Link> <i class="fa fa-angle-double-right" aria-hidden="true"></i> Notifications</span>
                        </div>

                        <Card>
                            <Col className="col-12">
                                <div style={{ padding: "20px" }}>
                                    <div className='table-responsive'>
                                        <table class="table table-hover" style={{ padding: "10px" }}>
                                            <tbody>
                                                <tr>
                                                    <th scope="row">1</th>
                                                    <td><a > Users can tap the notification to open your app or take an action directly from the notification. <span style={{ float: "right" }}><i style={{ fontSize: "18px" }} class="fa fa-times-circle-o" aria-hidden="true"></i></span></a></td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">2</th>
                                                    <td><a > Users can tap the notification to open your app or take an action directly from the notification. <span style={{ float: "right" }}><i style={{ fontSize: "18px" }} class="fa fa-times-circle-o" aria-hidden="true"></i></span></a></td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">3</th>
                                                    <td><a > Users can tap the notification to open your app or take an action directly from the notification. <span style={{ float: "right" }}><i style={{ fontSize: "18px" }} class="fa fa-times-circle-o" aria-hidden="true"></i></span></a></td>
                                                </tr>

                                                <tr>
                                                    <th scope="row">4</th>
                                                    <td><a > Users can tap the notification to open your app or take an action directly from the notification. <span style={{ float: "right" }}><i style={{ fontSize: "18px" }} class="fa fa-times-circle-o" aria-hidden="true"></i></span></a></td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">5</th>
                                                    <td><a > Users can tap the notification to open your app or take an action directly from the notification. <span style={{ float: "right" }}><i style={{ fontSize: "18px" }} class="fa fa-times-circle-o" aria-hidden="true"></i></span></a></td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">6</th>
                                                    <td><a > Users can tap the notification to open your app or take an action directly from the notification. <span style={{ float: "right" }}><i style={{ fontSize: "18px" }} class="fa fa-times-circle-o" aria-hidden="true"></i></span></a></td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">7</th>
                                                    <td><a > Users can tap the notification to open your app or take an action directly from the notification. <span style={{ float: "right" }}><i style={{ fontSize: "18px" }} class="fa fa-times-circle-o" aria-hidden="true"></i></span></a></td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">8</th>
                                                    <td><a > Users can tap the notification to open your app or take an action directly from the notification. <span style={{ float: "right" }}><i style={{ fontSize: "18px" }} class="fa fa-times-circle-o" aria-hidden="true"></i></span></a></td>
                                                </tr>
                                                <tr>
                                                    <th scope="row">9</th>
                                                    <td><a > Users can tap the notification to open your app or take an action directly from the notification. <span style={{ float: "right" }}><i style={{ fontSize: "18px" }} class="fa fa-times-circle-o" aria-hidden="true"></i></span></a></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                    <div style={{ float: "right" }} className="mt-2 mb-5">
                                        <Pagination count={3} variant="outlined" color="primary" />
                                    </div>
                                </div>
                            </Col>
                        </Card>
                    </Col>
                </Row>
            </Box>

        </div >
    )
}

export default Levelwise
