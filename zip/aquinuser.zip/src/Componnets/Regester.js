import React from 'react'
import { Row, Col, CardBody, Card, Alert, Container, Label } from "reactstrap"
import { withRouter, Link } from "react-router-dom"
import logo from "../assets/images/logo.png";

function Regester() {
    return (
        <div>
            <div className="account-pages my-5 pt-sm-5">
                <Container>
                    <Row className="justify-content-center">
                        <Col md={8} lg={6} xl={5}>
                            <Card className="overflow-hidden">
                                <CardBody className="pt-0">
                                    <h3 className="text-center mt-4">
                                        <Link to="/" className="d-block auth-logo">
                                        <img src={logo} style={{width:"200px"}} className="auth-logo-dark" />

                                            {/* <img src={logoDark} alt="" height="30" className="auth-logo-dark" />
                      <img src={logoLightPng} alt="" height="30" className="auth-logo-light" /> */}
                                        </Link>
                                    </h3>
                                    {/* <h2 className='text-center text-primary'>Aquin</h2> */}
                                    <div className="p-3">
                                        <h4 className="text-muted font-size-18 mb-1 text-center">Free Register</h4>
                                        <p className="text-muted text-center">Get your free Aquin account now.</p>

                                        <ul class="nav nav-pills nav-fill">
                                            <li class="nav-item">
                                                <Link to="/register">
                                                <i class="fa fa-address-book text-secondary regtab active " aria-hidden="true"></i>
                                                    <a class="nav-link text-secondary" >User detials</a>
                                                </Link>
                                            </li>
                                            <li class="nav-item">
                                                <Link to="/registers">
                                                <i class="fa fa-address-book text-secondary regtab active " aria-hidden="true"></i>
                                                    <a class="nav-link text-secondary">More details</a>
                                                </Link>
                                            </li>
                                        </ul>


                                        <div
                                            className="form-horizontal mt-4"
                                        //   onValidSubmit={(e, v) => {
                                        //     handleValidSubmit(e, v)
                                        //   }}
                                        >
                                            {/* {props.user && props.user ? (
                        <Alert color="success">
                          Register User Successfully
                        </Alert>
                      ) : null}

                      {props.registrationError &&
                        props.registrationError ? (
                        <Alert color="danger">
                          {props.registrationError}
                        </Alert>
                      ) : null} */}

                                            <div className="mb-3">
                                                <Label>Sponsor Id</Label>
                                                <input
                                                    id="SponsorId"
                                                    name="SponsorId"
                                                    className="form-control"
                                                    placeholder="Enter Sponsor Id"
                                                    type="number"
                                                    required
                                                />
                                            </div>

                                            <div className="mb-3">
                                                <Label>Name</Label>
                                                <input
                                                    name="name"
                                                    type="text"
                                                    className="form-control"
                                                    required
                                                    placeholder="Enter Name"
                                                />
                                            </div>
                                            <div className="mb-3">
                                                <Label>Mobile</Label>
                                                <input
                                                    name="mobile"
                                                    label="Mobile"
                                                    type="number"
                                                    className="form-control"
                                                    required
                                                    placeholder="Enter Mobile"
                                                />
                                            </div>
                                            <div className="mb-3">
                                                <Label>Date Of Birth</Label>
                                                <input
                                                    name="dob"
                                                    className="form-control"
                                                    type="date"
                                                    required
                                                    placeholder="Enter Date Of Birth"
                                                />
                                            </div>
                                            <div className="mb-3">
                                                {/* <input
                          name="dob"
                          label="Date Of Birth"
                          type="date"
                          required
                          placeholder="Enter Date Of Birth"
                        /> */}
                                                <Label>Gender</Label>
                                                <select className="form-control">
                                                    <option>Male</option>
                                                    <option>Female</option>
                                                </select>
                                            </div>

                                            {/* <div className="mb-3 row mt-4">
                        <div className="col-12 text-end">
                          <Link to="/registers"><button className="btn btn-primary w-md waves-effect waves-light" type="submit">Next</button></Link>
                        </div>
                      </div> */}
                                            <div style={{ float: "right" }}>
                                            <Link to="/registers"> <button style={{ width: "100px" }} className="btn btn-info w-md waves-effect waves-light">Next <i class="fa fa-arrow-circle-right" aria-hidden="true"></i></button></Link>

                                            </div>

                                            <div style={{padding:"50px 0px 0px 0px"}}>
                                                <div className="">
                                                    <p className="text-muted text-center mb-0 font-size-14">By registering you agree to the Aquin <Link to="#" className="text-primary">Terms of Use</Link></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </CardBody>
                            </Card>
                            <div className="text-center">
                                <p>
                                    Already have an account ?{" "}
                                    <Link to="/" className="text-primary">
                                        {" "}
                                        Login
                                    </Link>{" "}
                                </p>
                                <p>
                                    © {new Date().getFullYear()} Aquin
                                    <span className="d-none d-sm-inline-block"> - Designed <i class="fa fa-heart text-danger" aria-hidden="true"></i> by DigitalRaiz Creative Solutions.</span>
                                </p>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </div>
        </div>
    )
}

export default Regester