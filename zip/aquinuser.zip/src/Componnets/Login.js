import React, { useState } from 'react'
import { Row, Col, CardBody, Card, Alert, Container, Label } from "reactstrap"
import { withRouter, Link } from "react-router-dom"
import logo from "../assets/images/logo.png";
import axios from "axios"

function Login() {

    const [user, setUser] = useState({ email: "", password: "" })

    const handleChange = (e) => {
        let newadmin = { ...user };
        newadmin[e.target.name] = e.target.value;
        setUser(newadmin);
    };

    const usersign = (e) => {
        e.preventDefault();
        signin()
    }


    const signin = () => {
        var parse = {
            email: user.email,
            hash_password: user.hash_password
        }
        axios.post("http://103.186.185.77:5013/api/v1/web/aquin/user-signin", parse).then((res) => {
            console.log("success")
            sessionStorage.setItem("UserId", res.data.user._id)
            sessionStorage.setItem("email", res.data.user.email)
            sessionStorage.setItem("role", res.data.user.role)
            sessionStorage.setItem("token", res.data.token)
            window.location.href = "/Dashboard";

        })
    }

    return (
        <div>
            <div className="account-pages my-5 pt-sm-5">
                <Container>
                    <Row className="justify-content-center">
                        <Col md={8} lg={6} xl={5}>
                            <Card className="overflow-hidden">
                                <CardBody className="pt-0">
                                    <h3 className="text-center mt-4">
                                        <Link to="/" className="d-block auth-logo">
                                            <img src={logo} style={{ width: "200px" }} className="auth-logo-dark" />
                                            {/* <img src={logoLightPng} alt="" height="30" className="auth-logo-light" /> */}
                                        </Link>
                                    </h3>
                                    {/* <h2 className='text-center text-primary'>Aquin</h2> */}
                                    <div className="p-3">
                                        <h4 className="text-muted font-size-18 mb-1 text-center">Welcome Back !</h4>
                                        <p className="text-muted text-center">Sign in to continue to Aquin.</p>
                                        <form
                                        onSubmit={usersign}
                                            className="form-horizontal mt-4"

                                        >
                                            <div className="mb-3">
                                                <Label>Email</Label>
                                                <input
                                                    name="email"
                                                    value={user.email}
                                                    className="form-control"
                                                    placeholder="Enter email"
                                                    type="email"
                                                    required
                                                    onChange={(e) => { handleChange(e) }}
                                                />
                                            </div>

                                            <div className="mb-3">
                                                <Label>Password</Label>
                                                <input
                                                    name="hash_password"
                                                    className="form-control"
                                                    value={user.hash_password}
                                                    type="password"
                                                    required
                                                    placeholder="Enter Password"
                                                    onChange={(e) => { handleChange(e) }}
                                                />
                                            </div>

                                            <div className="mb-3 row mt-4">
                                                <div className="col-6">
                                                    <div className="form-check">
                                                        {/* <input
                                                            type="checkbox"
                                                            className="form-check-input"
                                                            id="customControlInline"
                                                        />
                                                        <label
                                                            className="form-check-label"
                                                            htmlFor="customControlInline"
                                                        >
                                                            Remember me
                                                        </label> */}
                                                    </div>
                                                </div>
                                                <div className="col-6">
                                                    <div style={{ float: "right" }}>
                                                        <button style={{ width: "100px" }} className="btn btn-info w-md waves-effect waves-light" type="submit" >Log In</button>
                                                    </div>
                                                </div>
                                            </div>
                                            <div className="form-group mb-0 row">
                                                <div className="col-12 mt-4">
                                                    <Link to="/forgot-password" className="text-muted"><i className="mdi mdi-lock"></i> Forgot your password?</Link>
                                                </div>
                                            </div>

                                        </form>
                                    </div>
                                </CardBody>
                            </Card>
                            <div className="mt-5 text-center">
                                <p>
                                    Don&#39;t have an account ?{" "}
                                    <Link
                                        to="/register"
                                        className="text-primary"
                                    >
                                        {" "}
                                        Signup now{" "}
                                    </Link>{" "}
                                </p>
                                <p>
                                    © {new Date().getFullYear()} Aquin
                                    <span className="d-none d-sm-inline-block"> - Designed <i class="fa fa-heart text-danger" aria-hidden="true"></i> by DigitalRaiz Creative Solutions.</span>
                                </p>
                            </div>
                        </Col>
                    </Row>
                </Container>
            </div>
        </div >
    )
}

export default Login