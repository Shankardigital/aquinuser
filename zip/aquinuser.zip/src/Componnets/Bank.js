import React, { useEffect, useState } from "react";
import Sidebar from "./Sidebar";
import Sidebarres from "./Sidebarres";
import {
  Row,
  Col,
  Card,
  CardBody,
  FormGroup,
  Button,
  CardTitle,
  Label,
  Input,
  ModalHeader,
  ModalBody,
  ModalFooter,
} from "reactstrap";
import Table from "react-bootstrap/Table";
import Box from "@mui/material/Box";
import CssBaseline from "@mui/material/CssBaseline";
import { NavLink, Link } from "react-router-dom";
import mark from "../assets/images/mark1.jpg";
import avatar from "../assets/images/users/user-1.jpg";
import MonetizationOnIcon from "@mui/icons-material/MonetizationOn";
import Pagination from "@mui/material/Pagination";
import Stack from "@mui/material/Stack";
import qrcode from "../assets/images/bank.jfif";
import pan from "../assets/images/pan.jfif";
import aadhar from "../assets/images/aadhar.jfif";
import user from "../assets/images/users/user-5.jpg";

// import { AvForm, input } from "availity-reactstrap-validation"
// import qrcode from "../assets/images/qrcode.png";
import Modal from "react-bootstrap/Modal";

import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";

function Bank() {
  const [modal, setModal] = useState(false);

  const toggle = () => setModal(!modal);
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  const [showResults, setShowResults] = React.useState(false);
  const showfield = () => setShowResults(true);
  const hidefield = () => setShowResults(false);

  const [editResults, seteditResults] = React.useState(false);
  const editfield = () => seteditResults(false);

  const [showResults2, setShowResults2] = React.useState(false);
  const hidefield2 = () => setShowResults2(false);
  const [editResults2, seteditResults2] = React.useState(false);
  const editfield2 = () => seteditResults2(false);

  const [bank, setbank] = React.useState(true);
  console.log(bank);
  const [upi, setupi] = React.useState(false);

  const [bankss, setbankss] = useState([]);
  console.log(bankss);
  const [form, setform] = useState([]);

  const banks = () => {
    var token = sessionStorage.getItem("token");
    var _id = sessionStorage.getItem("UserId");
    axios
      .post(
        "http://103.186.185.77:5013/api/v1/web/bank/getall-banks",
        { _id },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      )
      .then((res) => {
        if (res.status == 200) {
          setbankss(res.data.banks);
        }
      });
  };

  useEffect(() => {
    banks();
  }, []);

  const Optionchange = (e) => {
    let myUser = { ...form };
    myUser._id = e.target.value;
    setform(myUser);
  };


  //   --form 'bankId="633fd0e1fb51ecba9a971780"' \
// --form 'accountType="savings account"' \
// --form 'accountNumber="5496347609457845"' \
// --form 'ifscCode="KKBK0007457"' \
// --form 'passbookcopy=@"/C:/Users/NISHAT FATEMA/Downloads/wipro.pdf"' \
// --form 'passportImg=@"/C:/Users/NISHAT FATEMA/Downloads/tree-parts.jpg"' \
// --form 'pancardNumber="ALWPG5809L"' \
// --form 'panImg=@"/C:/Users/NISHAT FATEMA/Downloads/sdsrd.png"' \
// --form 'aadhaarcardNumber="125465236512"' \
// --form 'aadhaarImg=@"/C:/Users/NISHAT FATEMA/Downloads/qrcodes.png"'


const [Files, setFiles] = useState("");

const changeHandler = (e) => {
  setFiles(e.target.files);
};

  const add = () => {
    const dataArray = new FormData();
    dataArray.append("bankId", form.bankId);
    dataArray.append("accountType", form.accountType);
    dataArray.append("accountNumber", form.accountNumber);
    dataArray.append("ifscCode", form.ifscCode);


    for (let i = 0; i < Files.length; i++) {
      dataArray.append("panImg", Files[i]);
    }

    for (let i = 0; i < Files.length; i++) {
        dataArray.append("panImg", Files[i]);
      }
  

    for (let i = 0; i < Files.length; i++) {
        dataArray.append("aadhaarImg", Files[i]);
      }

    
    for (let i = 0; i < Files.length; i++) {
        dataArray.append("passportImg", Files[i]);
      }




    var token = sessionStorage.getItem("token");
    axios
      .post(
        "http://103.186.185.77:5013/api/v1/web/aquin/user-addmember",
        dataArray,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      )
      .then(
        (res) => {
          if (res.status === 200) {
            toast(res.data.message);
            handleClose();
            // clearForm();
          }
        },
        (error) => {
          if (error.response && error.response.status === 400) {
            toast(error.response.data.message);
          }
        }
      );
  };





  return (
    <div>
      {/* <Sidebar/> */}

      <Box sx={{ display: "flex" }} className="cardmrg">
        <div className="backgrounimgstyle">
          <Sidebar />
        </div>
        <div className="drawecontent">
          <Sidebarres />
        </div>
        {/* <CssBaseline /> */}
        <Row className="continer cotainerstyle2 mb-5" style={{ width: "100%" }}>
          <Col md={12}>
            <div className="mb-4">
              <h5>Bank Details</h5>
              <span style={{ fontSize: " 15px" }}>
                <Link to="/Dashboard">Aquin</Link>{" "}
                <i class="fa fa-angle-double-right" aria-hidden="true"></i> Bank
                Details
              </span>
            </div>
            {showResults ? (
              <Card>
                <CardBody>
                  <CardTitle className="h4">Add Bank Details </CardTitle>
                  <div className="mt-4">
                    <div className="needs-validation">
                      <Row>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom01">Bank</Label>
                            <select
                              errorMessage=" Please provide a valid State"
                              id="validationCustom03"
                              className="form-control"
                              required
                              name="bankId"
                              onChange={(e) => {
                                Optionchange(e);
                              }}
                              value={form.bankId}
                            >
                              <option value="">select bank Name </option>
                              {bankss.map((opt) => {
                                return (
                                  <option value={opt._id}>{opt.title}</option>
                                );
                              })}
                            </select>
                          </div>
                        </Col>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom07">
                              Account Name
                            </Label>
                            <input
                              name="AccountName"
                              placeholder="Account Name"
                              type="text"
                              errorMessage="Account Name"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom07"
                            />
                          </div>
                        </Col>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom01">
                              Account Number
                            </Label>
                            <input
                              name="AccountNumber"
                              placeholder="Account Number"
                              type="number"
                              errorMessage="Account Number"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom01"
                            />
                          </div>
                        </Col>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom07">
                              IFSC Code
                            </Label>
                            <input
                              name="IFSCCode"
                              placeholder="IFSC Code"
                              type="text"
                              errorMessage="IFSC Code"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom07"
                            />
                          </div>
                        </Col>
                      </Row>
                      <Row>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom01">
                              Bank Book
                            </Label>
                            <input
                              name="Bank"
                              type="file"
                              errorMessage="Bank Book"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom01"
                            />
                          </div>
                        </Col>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom07">
                              Passphoto
                            </Label>
                            <input
                              name="Passphoto"
                              type="file"
                              errorMessage="Passphoto"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom07"
                            />
                          </div>
                        </Col>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom07">
                              Aadhar Card No
                            </Label>
                            <input
                              name="Aadhar Card No"
                              placeholder="AadharNo"
                              type="number"
                              errorMessage="Aadhar Card No"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom07"
                            />
                          </div>
                        </Col>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom07">
                              Aadhar Card
                            </Label>
                            <input
                              name="Aadhar"
                              type="file"
                              errorMessage="Aadhar Card Image/Pdf"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom07"
                            />
                          </div>
                        </Col>
                      </Row>

                      <Row>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom07">
                              Pan Card No
                            </Label>
                            <input
                              name="PanNo"
                              placeholder="Pan Card No"
                              type="text"
                              errorMessage="Pan Card No"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom07"
                            />
                          </div>
                        </Col>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom07">Pan Card</Label>
                            <input
                              name="PanCard"
                              type="file"
                              errorMessage="Pan Card Image/Pdf"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom07"
                            />
                          </div>
                        </Col>
                        <Col md="4">
                          <div className="mb-4 mt-4">
                            <Button
                              className="btn btn-success listbtns"
                              style={{ width: "110px" }}
                            >
                              Submit
                            </Button>
                            <Button
                              className="btn-danger listbtns"
                              style={{ width: "110px" }}
                              onClick={hidefield}
                            >
                              Cancel
                            </Button>
                          </div>
                        </Col>
                      </Row>
                    </div>
                  </div>
                </CardBody>
              </Card>
            ) : (
              ""
            )}
            {editResults ? (
              <Card>
                <CardBody>
                  <CardTitle className="h4">Edit Bank Details </CardTitle>
                  <div className="mt-4">
                    <div className="needs-validation">
                      <Row>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom01">Bank Name</Label>
                            <input
                              name="Bank"
                              placeholder="Bank"
                              type="text"
                              errorMessage="Bank"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom01"
                              value="Axis Bank"
                            />
                          </div>
                        </Col>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom07">
                              Account Name
                            </Label>
                            <input
                              name="AccountName"
                              placeholder="Account Name"
                              type="text"
                              errorMessage="Account Name"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom07"
                              value="Syed"
                            />
                          </div>
                        </Col>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom01">
                              Account Number
                            </Label>
                            <input
                              name="AccountNumber"
                              placeholder="Account Number"
                              type="number"
                              errorMessage="Account Number"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom01"
                              value="912020011386272"
                            />
                          </div>
                        </Col>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom07">
                              IFSC Code
                            </Label>
                            <input
                              name="IFSCCode"
                              placeholder="IFSC Code"
                              type="text"
                              errorMessage="IFSC Code"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom07"
                              value="UTIB0000394"
                            />
                          </div>
                        </Col>
                      </Row>
                      <Row>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom01">
                              Bank Book
                            </Label>
                            <input
                              name="Bank"
                              type="file"
                              // value={qrcode}
                              errorMessage="Bank Book"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom01"
                            />
                            <img
                              className="mt-2"
                              src={qrcode}
                              style={{ width: "100%", height: "90px" }}
                            />
                          </div>
                        </Col>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom07">
                              Passphoto
                            </Label>
                            <input
                              name="Passphoto"
                              type="file"
                              // value={user}
                              errorMessage="Passphoto"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom07"
                            />
                            <img
                              className="mt-2"
                              src={user}
                              style={{ width: "100%", height: "90px" }}
                            />
                          </div>
                        </Col>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom07">
                              Aadhar Card No
                            </Label>
                            <input
                              name="Aadhar Card No"
                              placeholder="AadharNo"
                              type="text"
                              errorMessage="Aadhar Card No"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom07"
                              value="685236945269"
                            />
                          </div>
                        </Col>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom07">
                              Aadhar Card
                            </Label>
                            <input
                              name="Aadhar"
                              type="file"
                              errorMessage="Aadhar Card Image/Pdf"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom07"
                            />
                            <img
                              className="mt-2"
                              src={aadhar}
                              style={{ width: "100%", height: "90px" }}
                            />
                          </div>
                        </Col>
                      </Row>
                      <Row>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom07">
                              Pan Card No
                            </Label>
                            <input
                              name="PanNo"
                              placeholder="Pan Card No"
                              type="text"
                              errorMessage="Pan Card No"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom07"
                              value="BDZER2059F"
                            />
                          </div>
                        </Col>
                        <Col md="3">
                          <div className="mb-4">
                            <Label htmlFor="validationCustom07">Pan Card</Label>
                            <input
                              name="PanCard"
                              type="file"
                              errorMessage="Pan Card Image/Pdf"
                              className="form-control"
                              validate={{ required: { value: true } }}
                              id="validationCustom07"
                            />
                            <img
                              className="mt-2"
                              src={pan}
                              style={{ width: "100%", height: "90px" }}
                            />
                          </div>
                        </Col>
                        <Col md="4">
                          <div className="mb-4 mt-4">
                            <Button
                              className="btn btn-success listbtns"
                              style={{ width: "110px" }}
                            >
                              Submit
                            </Button>
                            <Button
                              className="btn-danger listbtns"
                              style={{ width: "110px" }}
                              onClick={editfield}
                            >
                              Cancel
                            </Button>
                          </div>
                        </Col>
                      </Row>
                    </div>
                  </div>
                </CardBody>
              </Card>
            ) : (
              ""
            )}

            <Card>
              <CardBody>
                {/* <CardTitle className="h4">Bank Details </CardTitle> */}
                <div style={{ float: "right" }}>
                  {/* <button className="btn btn-success listbtns"><i class="fa fa-file-pdf" aria-hidden="true"></i> PDF</button>
                                <button className="btn btn-danger listbtns"><i class="fa fa-file-excel" aria-hidden="true"></i> Excel</button> */}
                  <button
                    className="btn btn-primary"
                    style={{ margin: "6px" }}
                    onClick={() => {
                      setShowResults(!showResults);
                    }}
                  >
                    <i class="fa fa-plus-circle" aria-hidden="true">
                      {" "}
                    </i>{" "}
                    Add Bank
                  </button>

                  <button
                    className="btn btn-info"
                    onClick={() => {
                      seteditResults(!editResults);
                    }}
                  >
                    <i class="fa fa-pencil-square-o" aria-hidden="true"></i>{" "}
                    Edit Bank
                  </button>
                </div>
                {/* <div >
                                <select className="form-control mt-2" style={{ width: "150px" }}>
                                    <option onClick={() => { setbank(!bank) }}>Bank</option>
                                    <option onClick={() => { setupi(!upi) }}>UPI</option>
                                </select>
                            </div> */}

                {/* <p className="card-title-desc">
                    mdbreact DataTables has most features enabled by default, so
                    all you need to do to use it with your own tables is to call
                    the construction function:{" "}
                    <code>&lt;MDBDataTable striped /&gt;</code>.
                  </p> */}
                {bank ? (
                  <div className=" bankstyle mb-4">
                    <div className="table-responsive">
                      <Table className="table-bordered border-primary mb-0">
                        {/* <thead>
                    <tr>
                      <th>#</th>
                      <th>First Name</th>
                      <th>Last Name</th>
                      <th>Username</th>
                    </tr>
                  </thead> */}
                        <tbody>
                          <tr>
                            <th scope="row">Bank :</th>
                            <td>Axis Bank</td>
                          </tr>
                          <tr>
                            <th scope="row">Account Name :</th>
                            <td>Syed</td>
                          </tr>
                          <tr>
                            <th scope="row">Account Number :</th>
                            <td>912020011386272</td>
                          </tr>
                          <tr>
                            <th scope="row">IFSC Code :</th>
                            <td>UTIB0000394</td>
                          </tr>
                          <tr>
                            <th scope="row">Pan Card No :</th>
                            <td>BDZER2059F</td>
                          </tr>
                          <tr>
                            <th scope="row">Aadhar Card No :</th>
                            <td>685236945269</td>
                          </tr>
                        </tbody>
                      </Table>
                    </div>
                  </div>
                ) : (
                  ""
                )}

                {/* <MDBDataTable className="mt-5" responsive striped bordered data={data} /> */}
              </CardBody>
            </Card>
          </Col>
        </Row>
      </Box>
      {/* <Modal
          isOpen={modal}
          style={{ width: '30%', marginTop: "100px" }}
          toggle={toggle}
        >
          <ModalHeader toggle={toggle}>
              <span>QRCODE</span>
          </ModalHeader>
          <ModalBody>
            <img src={qrcode} style={{ width: "100%" }} />
          </ModalBody>
        </Modal> */}

      <Modal
        show={show}
        size="sm"
        style={{ marginTop: "100px" }}
        onHide={handleClose}
      >
        <Modal.Header closeButton>
          <Modal.Title>Modal heading </Modal.Title>
          <span
            onClick={handleClose}
            style={{ float: "right", fontSize: "20px" }}
          >
            <i class="fa fa-times-circle" aria-hidden="true"></i>
          </span>
        </Modal.Header>
        <Modal.Body>
          <img src={qrcode} style={{ width: "100%" }} />
        </Modal.Body>
      </Modal>
    </div>
  );
}

export default Bank;
